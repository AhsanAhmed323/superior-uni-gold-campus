from flask import Flask, render_template
import requests
app = Flask(__name__)

# our nasa api
NASA_API_KEY = "BbMiYnglMHobUrhDGPnHNQT4HI3WZdmT15kYOZ7C"

# nasa api endpoint
APOD_URL = "https://api.nasa.gov/planetary/apod"

@app.route('/', methods=['GET'])
def index():
    # fetching data from the nasa api
    params = {"api_key": NASA_API_KEY}
    response = requests.get(APOD_URL, params=params)
    apod_data = response.json()

    # rendering the data to the index.html
    return render_template('index.html', apod_data=apod_data)

if __name__ == '__main__':
    app.run(debug=False)